//I think unit testing this would require moving the event handler functions in side_panel.ts to a small class
// so that DomWrapper and ChromeWrapper could be injected for testing (also the logger)
// That class would also be given the needed html elements as constructor arguments