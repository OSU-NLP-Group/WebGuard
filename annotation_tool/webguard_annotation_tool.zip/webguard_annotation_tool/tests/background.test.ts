//todo it is possible (just annoying) to test the methods remaining in background.ts by using jest to manipulate
// the script-global variables